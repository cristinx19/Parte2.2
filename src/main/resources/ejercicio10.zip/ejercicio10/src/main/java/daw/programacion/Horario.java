package daw.programacion;
import java.util.*;


/**
 * Class Horario
 */
public class Horario {

  //
  // Fields
  //

  //
  // Constructors
  //
  public Horario () {};
  
  //
  // Methods
  //


  //
  // Accessor methods
  //


  //
  // Other methods
  //

}
